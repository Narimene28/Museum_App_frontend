package com.example.relicsofturkiye;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ListPlanetsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MuseumListFragment extends Fragment{
    MuseumViewModel museumViewModel;
    FragmentMuseumListsBinding binding;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        museumViewModel = new ViewModelProvider(getActivity()).get(MuseumViewModel.class);

        binding = FragmentMuseumListsBinding.inflate(getLayoutInflater());

        binding.recMuseums.setLayoutManager(new LinearLayoutManager(getActivity()));

        MuseumAdapter adp = new MuseumAdapter(getActivity(),MuseumViewModel.MuseumsData.getValue());

        binding.recMuseums.setAdapter(adp);


        return binding.getRoot();
    }

}
