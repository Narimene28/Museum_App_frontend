package com.example.relicsofturkiye;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toolbar;

public class MuseumListActivity extends AppCompatActivity {
    Toolbar toolBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_museum_list);

        NavHostFragment navHost = (NavHostFragment)getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
        NavController navController = navHost.getNavController();

        AppBarConfiguration conf = new AppBarConfiguration.Builder(navController.getGraph()).build();

        toolBar = findViewById(R.id.toolbar);

        NavigationUI.setupWithNavController(toolBar,navController,conf);

        new ViewModelProvider(this).get(PlanetViewModel.class);

    }

    public Toolbar getToolBar() {
        return toolBar;
    }
}