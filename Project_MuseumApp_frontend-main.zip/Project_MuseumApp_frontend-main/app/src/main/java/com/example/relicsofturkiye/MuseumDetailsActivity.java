package com.example.relicsofturkiye;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MuseumDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_museum_details);
    }
}