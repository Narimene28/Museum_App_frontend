package com.example.relicsofturkiye;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MusuemAdapter extends RecyclerView.Adapter<MuseumAdapter.MuseumViewHolder>{

    Context ctx;
    List<Museum> data;

    public MusuemAdapter(Context ctx, List<Museum> data) {
        this.ctx = ctx;
        this.data = data;
    }

    @NonNull
    @Override
    public MuseumViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View root = LayoutInflater.from(ctx).inflate(R.layout.museum_row_layout,parent,false);

        MuseumViewHolder holder = new MuseumViewHolder(root);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MuseumViewHolder holder, int position) {

        holder.txtMuseumRow.setText(data.get(position).getName());

        holder.imgMuseumRow.setImageResource(data.get(position).getImg());

        holder.setIsRecyclable(false);

        holder.row.setOnClickListener(v->{

            MuseumViewModel viewModel =
                    new ViewModelProvider((AppCompatActivity)ctx).get(MuseumViewModel.class);

            viewModel.setSelectedMuseum(data.get(position));

            NavController navController = Navigation.findNavController((AppCompatActivity)ctx,R.id.fragmentContainerView);

            navController.navigate(R.id.action_listMuseumsFragment_to_detailFragment);



        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class MuseumViewHolder extends RecyclerView.ViewHolder{

        ConstraintLayout row;
        ImageView imgMuseumRow;
        TextView txtPlanetRow;
        public MusuemViewHolder(@NonNull View itemView){
            super(itemView);

            row = itemView.findViewById(R.id.rowContainer);
            imgMuseumRow = itemView.findViewById(R.id.imgRowMuseum);
            txtPlanetRow = itemView.findViewById(R.id.txtMuseumRow);
        }
    }
}
