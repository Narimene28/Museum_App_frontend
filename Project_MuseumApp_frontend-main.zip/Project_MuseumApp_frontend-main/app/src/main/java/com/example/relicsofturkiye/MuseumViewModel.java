package com.example.relicsofturkiye;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;

public class MuseumViewModel extends ViewModel {
    LiveData<List<Museum>> museumData;
    MutableLiveData<Museum> selectedMuseum = new MutableLiveData<>();

    public MuseumViewModel(){

        Museum m1 = new Museum("Topkapi Palace", R.drawable.topkapi, "The Topkapı Palace, or the Seraglio, is a large museum and library in the east of the Fatih district of Istanbul in Turkey. From the 1460s to the completion of Dolmabahçe Palace in 1856, it served as the administrative center of the Ottoman Empire, and was the main residence of its sultans.");
        Museum m2 = new Museum("Galata Tower", R.drawable.galata, "The Galata Tower, officially the Galata Tower Museum, is an old Genoese tower in the Galata part of the Beyoğlu district of Istanbul, Turkey. Built as a watchtower at the highest point of the Walls of Galata, the tower is now an exhibition space and museum, and a symbol of Beyoğlu and Istanbul.");
        Museum m3 = new Museum("Turkish and Islamic Arts", R.drawable.islamic_arts, "The Turkish and Islamic Arts Museum (Turkish: Türk ve İslam Eserleri Müzesi) is a museum located in Sultanahmet Square in Fatih district of Istanbul, Turkey.");
        Museum m4 = new Museum("Istanbul Modern", R.drawable.modern_arts, "Istanbul Modern, a.k.a. Istanbul Museum of Modern Art, is a contemporary art gallery located inside the Galataport complex in the Beyoğlu district of Istanbul, Turkey. Inaugurated on December 11, 2004, Istanbul Modern was Turkey's first modern and contemporary art gallery and focuses on Turkish artists.");
        List<Museum> museums = new ArrayList<>();
        museums.add(m1);
        museums.add(m2);
        museums.add(m3);
        museums.add(m4);

        museumData = new MutableLiveData<>(museums);

    }
}
